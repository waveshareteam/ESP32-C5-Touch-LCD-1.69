#pragma once

#include <Arduino.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define BSP_LCD_H_RES                240
#define BSP_LCD_V_RES                280
#define BSP_LCD_Y_OFFSET             20
#define BSP_LCD_BITS_PER_PIXEL       16
#define BSP_LCD_BIGENDIAN            0

#define BSP_LCD_BACKLIGHT_FREQ_HZ    5000UL
#define BSP_LCD_BACKLIGHT_RES_BITS   10UL

#define BSP_I2C_CLOCK_HZ             400000UL
#define BSP_I2C_SCL                  9
#define BSP_I2C_SDA                  8

#define BSP_LCD_SPI_CLOCK_HZ         80000000UL
#define BSP_LCD_CS                   27
#define BSP_LCD_CLK                  23
#define BSP_LCD_DATA                 7
#define BSP_LCD_DC                   24
#define BSP_LCD_BACKLIGHT            26
#define BSP_LCD_RST                  (-1)

#define BSP_I2S_MCLK                 0
#define BSP_I2S_SCLK                 1
#define BSP_I2S_LCLK                 3
#define BSP_I2S_DSIN                 2
#define BSP_I2S_DOUT                 10

#define BSP_AUDIO_INPUT_SAMPLE_RATE_HZ   24000UL
#define BSP_AUDIO_OUTPUT_SAMPLE_RATE_HZ  24000UL

typedef struct {
    uint8_t rotation;
    bool swap_xy;
    bool mirror_x;
    bool mirror_y;
} bsp_display_cfg_t;

typedef struct {
    bool use_psram;
    bool double_buffer;
    bool full_refresh;
} bsp_display_lvgl_full_frame_cfg_t;

typedef struct {
    bool use_psram;
    bool double_buffer;
    uint16_t buffer_height;
} bsp_display_lvgl_partial_cfg_t;

typedef struct {
    bool pressed;
    uint16_t x;
    uint16_t y;
} bsp_touch_data_t;

typedef struct {
    uint16_t mv;
    int16_t ma;
    int16_t max_load;
    int16_t mw;
    uint16_t soc;
    uint16_t tte;
    uint16_t ttf;
    uint16_t mah_rem;
    uint16_t mah_fcc;
    uint16_t cycles;
    uint16_t soh;
    int16_t tc;
} bsp_bat_info_t;

bool bsp_i2c_init(void);
bool bsp_display_init(void);
bool bsp_display_init_with_config(const bsp_display_cfg_t *cfg);
bool bsp_display_fill(uint16_t color);
bool bsp_display_draw_bitmap(int x_start, int y_start, int x_end, int y_end, const uint16_t *data);
bool bsp_display_brightness_init(void);
bool bsp_display_brightness_set(uint8_t brightness_percent);
int bsp_display_brightness_get(void);
bool bsp_display_backlight_on(void);
bool bsp_display_backlight_off(void);

bool bsp_touch_init(void);
bool bsp_touch_get_coordinates(bsp_touch_data_t *data);

bool bsp_bat_init(uint16_t mah);
bool bsp_get_bat_info(bsp_bat_info_t *bat_info);
bool bsp_bat_is_connected(void);

bool bsp_audio_init(void);
bool bsp_audio_deinit(void);
bool bsp_audio_poweramp_enable(bool enable);
bool bsp_audio_set_speaker_volume(uint8_t volume_percent);
bool bsp_audio_set_mic_gain(uint8_t gain_db);
bool bsp_audio_read(void *data, size_t len, size_t *bytes_read);
bool bsp_audio_write(const void *data, size_t len, size_t *bytes_written);

void *bsp_display_start(void);
void *bsp_display_start_full_frame(const bsp_display_lvgl_full_frame_cfg_t *cfg);
void *bsp_display_start_partial(const bsp_display_lvgl_partial_cfg_t *cfg);
bool bsp_display_lock(uint32_t timeoutMs);
void bsp_display_unlock(void);

#ifdef __cplusplus
}
#endif

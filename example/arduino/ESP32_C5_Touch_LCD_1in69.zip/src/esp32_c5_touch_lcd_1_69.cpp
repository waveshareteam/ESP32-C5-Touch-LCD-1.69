#include "esp32_c5_touch_lcd_1_69.h"
#include "peripherals/board_i2c.h"
#include <BQ27220.h>
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_vendor.h"
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

static const bsp_display_cfg_t default_display_cfg = {
    .rotation = 0,
    .swap_xy = false,
    .mirror_x = false,
    .mirror_y = false,
};

static bool lcd_initialized = false;
static bool spi_bus_initialized = false;
static bool backlight_initialized = false;
static bool bq27220_initialized = false;
static uint8_t backlight_percent = 0;
static uint16_t bq27220_capacity_mah = 0;
static bsp_display_cfg_t display_cfg = {};
static esp_lcd_panel_handle_t panel_handle = NULL;
static esp_lcd_panel_io_handle_t panel_io_handle = NULL;
static SemaphoreHandle_t lcd_flush_done = NULL;
static uint16_t fill_line[BSP_LCD_H_RES];
static BQ27220 bq27220;

static constexpr spi_host_device_t board_lcd_spi_host = SPI2_HOST;

static bool IRAM_ATTR lcd_color_trans_done(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_io_event_data_t *edata, void *user_ctx)
{
    BaseType_t need_yield = pdFALSE;
    SemaphoreHandle_t flush_done = (SemaphoreHandle_t)user_ctx;

    (void)panel_io;
    (void)edata;

    if (flush_done != NULL) {
        xSemaphoreGiveFromISR(flush_done, &need_yield);
    }

    return (need_yield == pdTRUE);
}

static bool lcd_wait_flush_done(void)
{
    if (lcd_flush_done == NULL) {
        return false;
    }

    return xSemaphoreTake(lcd_flush_done, pdMS_TO_TICKS(100)) == pdTRUE;
}

static bool lcd_apply_orientation(const bsp_display_cfg_t *cfg)
{
    if ((cfg == NULL) || (panel_handle == NULL)) {
        return false;
    }

    if (esp_lcd_panel_mirror(panel_handle, cfg->mirror_x, cfg->mirror_y) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_swap_xy(panel_handle, cfg->swap_xy) != ESP_OK) {
        return false;
    }

    return true;
}

static bool lcd_init_bus(void)
{
    spi_bus_config_t bus_cfg = {};

    if (spi_bus_initialized) {
        return true;
    }

    bus_cfg.sclk_io_num = BSP_LCD_CLK;
    bus_cfg.mosi_io_num = BSP_LCD_DATA;
    bus_cfg.miso_io_num = -1;
    bus_cfg.quadwp_io_num = -1;
    bus_cfg.quadhd_io_num = -1;
    bus_cfg.max_transfer_sz = BSP_LCD_H_RES * BSP_LCD_V_RES * (BSP_LCD_BITS_PER_PIXEL / 8);

    if (spi_bus_initialize(board_lcd_spi_host, &bus_cfg, SPI_DMA_CH_AUTO) != ESP_OK) {
        return false;
    }

    spi_bus_initialized = true;
    return true;
}

static bool lcd_init_panel(void)
{
    esp_lcd_panel_io_spi_config_t io_config = {};
    esp_lcd_panel_dev_config_t panel_config = {};

    if (panel_handle != NULL) {
        return true;
    }

    io_config.cs_gpio_num = BSP_LCD_CS;
    io_config.dc_gpio_num = BSP_LCD_DC;
    io_config.spi_mode = 0;
    io_config.pclk_hz = BSP_LCD_SPI_CLOCK_HZ;
    io_config.trans_queue_depth = 40;
    io_config.on_color_trans_done = lcd_color_trans_done;
    io_config.user_ctx = lcd_flush_done;
    io_config.lcd_cmd_bits = 8;
    io_config.lcd_param_bits = 8;

    if (esp_lcd_new_panel_io_spi(board_lcd_spi_host, &io_config, &panel_io_handle) != ESP_OK) {
        return false;
    }

    panel_config.reset_gpio_num = BSP_LCD_RST;
    panel_config.rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB;
    panel_config.bits_per_pixel = BSP_LCD_BITS_PER_PIXEL;
    panel_config.flags.reset_active_high = 0;

    if (esp_lcd_new_panel_st7789(panel_io_handle, &panel_config, &panel_handle) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_reset(panel_handle) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_init(panel_handle) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_disp_on_off(panel_handle, true) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_invert_color(panel_handle, true) != ESP_OK) {
        return false;
    }

    if (esp_lcd_panel_set_gap(panel_handle, 0, BSP_LCD_Y_OFFSET) != ESP_OK) {
        return false;
    }

    return true;
}

static bool lcd_init(const bsp_display_cfg_t *cfg)
{
    if (cfg == NULL) {
        return false;
    }

    if (lcd_flush_done == NULL) {
        lcd_flush_done = xSemaphoreCreateBinary();
        if (lcd_flush_done == NULL) {
            return false;
        }
    }

    if (!lcd_init_bus()) {
        return false;
    }

    if (!lcd_init_panel()) {
        return false;
    }

    display_cfg = *cfg;

    if (!lcd_apply_orientation(&display_cfg)) {
        return false;
    }

    lcd_initialized = true;
    return true;
}

static bool lcd_fill(uint16_t color)
{
    size_t x = 0;
    int y = 0;

    if (!lcd_initialized) {
        return false;
    }

    for (x = 0; x < BSP_LCD_H_RES; x++) {
        fill_line[x] = color;
    }

    for (y = 0; y < BSP_LCD_V_RES; y++) {
        xSemaphoreTake(lcd_flush_done, 0);
        if (esp_lcd_panel_draw_bitmap(panel_handle, 0, y, BSP_LCD_H_RES, y + 1, fill_line) != ESP_OK) {
            return false;
        }
        if (!lcd_wait_flush_done()) {
            return false;
        }
    }

    return true;
}

static bool lcd_draw_bitmap(int x_start, int y_start, int x_end, int y_end, const uint16_t *data)
{
    if (!lcd_initialized || (data == NULL)) {
        return false;
    }

    if ((x_start < 0) || (y_start < 0) || (x_end <= x_start) || (y_end <= y_start)) {
        return false;
    }

    if ((x_end > BSP_LCD_H_RES) || (y_end > BSP_LCD_V_RES)) {
        return false;
    }

    xSemaphoreTake(lcd_flush_done, 0);

    if (esp_lcd_panel_draw_bitmap(panel_handle, x_start, y_start, x_end, y_end, data) != ESP_OK) {
        return false;
    }

    return lcd_wait_flush_done();
}

static bool board_backlight_init(void)
{
    ledc_channel_config_t channel_cfg = {};
    ledc_timer_config_t timer_cfg = {};

    if (backlight_initialized) {
        return true;
    }

    timer_cfg.speed_mode = LEDC_LOW_SPEED_MODE;
    timer_cfg.duty_resolution = (ledc_timer_bit_t)BSP_LCD_BACKLIGHT_RES_BITS;
    timer_cfg.timer_num = LEDC_TIMER_1;
    timer_cfg.freq_hz = BSP_LCD_BACKLIGHT_FREQ_HZ;
    timer_cfg.clk_cfg = LEDC_AUTO_CLK;

    if (ledc_timer_config(&timer_cfg) != ESP_OK) {
        return false;
    }

    channel_cfg.gpio_num = BSP_LCD_BACKLIGHT;
    channel_cfg.speed_mode = LEDC_LOW_SPEED_MODE;
    channel_cfg.channel = LEDC_CHANNEL_0;
    channel_cfg.intr_type = LEDC_INTR_DISABLE;
    channel_cfg.timer_sel = LEDC_TIMER_1;
    channel_cfg.duty = 0;
    channel_cfg.hpoint = 0;

    if (ledc_channel_config(&channel_cfg) != ESP_OK) {
        return false;
    }

    backlight_initialized = true;
    backlight_percent = 0;
    return true;
}

static bool board_backlight_set(uint8_t brightness_percent)
{
    uint32_t duty_max = (1U << BSP_LCD_BACKLIGHT_RES_BITS) - 1U;
    uint32_t duty = 0;

    if (!board_backlight_init()) {
        return false;
    }

    if (brightness_percent > 100) {
        brightness_percent = 100;
    }

    duty = (duty_max * brightness_percent) / 100U;

    if (ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty) != ESP_OK) {
        return false;
    }

    if (ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0) != ESP_OK) {
        return false;
    }

    backlight_percent = brightness_percent;
    return true;
}

static int board_backlight_get(void)
{
    return backlight_percent;
}

typedef struct {
    uint16_t voltage;
    int16_t current;
    uint16_t remaining_capacity;
    uint16_t full_charge_capacity;
    uint16_t temperature;
    uint16_t cycle_count;
    uint16_t state_of_charge;
    int16_t average_power;
    int16_t maxload_current;
    uint16_t time_to_empty;
    uint16_t time_to_full;
    uint16_t state_of_health;
} bsp_bq27220_measurement_t;

namespace bq27220_cfg {
struct dm_addr_t {
    static constexpr uint16_t gauging_configuration = 0x929B;
    static constexpr uint16_t full_charge_capacity = 0x929D;
    static constexpr uint16_t design_capacity = 0x929F;
    static constexpr uint16_t self_discharge_rate = 0x9268;
    static constexpr uint16_t near_full = 0x926B;
    static constexpr uint16_t reserve_capacity = 0x926D;
    static constexpr uint16_t emf = 0x92A7;
    static constexpr uint16_t c0 = 0x92A9;
    static constexpr uint16_t r0 = 0x92AB;
    static constexpr uint16_t t0 = 0x92AD;
    static constexpr uint16_t r1 = 0x92AF;
    static constexpr uint16_t tc = 0x92B1;
    static constexpr uint16_t edv0 = 0x92B4;
    static constexpr uint16_t edv1 = 0x92B7;
    static constexpr uint16_t edv2 = 0x92BA;
    static constexpr uint16_t dod0 = 0x92BD;
    static constexpr uint16_t dod10 = 0x92BF;
    static constexpr uint16_t dod20 = 0x92C1;
    static constexpr uint16_t dod30 = 0x92C3;
    static constexpr uint16_t dod40 = 0x92C5;
    static constexpr uint16_t dod50 = 0x92C7;
    static constexpr uint16_t dod60 = 0x92C9;
    static constexpr uint16_t dod70 = 0x92CB;
    static constexpr uint16_t dod80 = 0x92CD;
    static constexpr uint16_t dod90 = 0x92CF;
    static constexpr uint16_t dod100 = 0x92D1;
};

static constexpr uint16_t operation_status_cfgupdate_mask = 0x0400;
static constexpr uint16_t ctrl_enter_cfg_update = 0x0090;
static constexpr uint16_t ctrl_exit_cfg_update = 0x0092;
static constexpr uint16_t ctrl_exit_cfg_update_reinit = 0x0091;
static constexpr uint16_t gauging_configuration_default = 0x1C11;
} // namespace bq27220_cfg

typedef struct {
    uint16_t full_charge_cap;
    uint16_t design_cap;
    uint16_t reserve_cap;
    uint16_t near_full;
    uint16_t self_discharge_rate;
    uint16_t edv0;
    uint16_t edv1;
    uint16_t edv2;
    uint16_t emf;
    uint16_t c0;
    uint16_t r0;
    uint16_t t0;
    uint16_t r1;
    uint8_t tc;
    uint8_t c1;
    uint16_t dod0;
    uint16_t dod10;
    uint16_t dod20;
    uint16_t dod30;
    uint16_t dod40;
    uint16_t dod50;
    uint16_t dod60;
    uint16_t dod70;
    uint16_t dod80;
    uint16_t dod90;
    uint16_t dod100;
} bq27220_profile_t;

static bool bat_write_control(uint16_t subcommand)
{
    return bq27220.writeWord(0x00, subcommand);
}

static bool bat_unseal(void)
{
    if (!bat_write_control(BQ27220_CTRL_UNSEAL_KEY1)) {
        return false;
    }
    delay(10);

    return bat_write_control(BQ27220_CTRL_UNSEAL_KEY2);
}

static bool bat_wait_cfgupdate(bool expected)
{
    uint32_t start_ms = millis();

    while ((millis() - start_ms) < 2000) {
        uint16_t operation_status = 0;
        bool cfgupdate = false;

        if (!bq27220.readOperationStatus(operation_status)) {
            return false;
        }

        cfgupdate = (operation_status & bq27220_cfg::operation_status_cfgupdate_mask) != 0;
        if (cfgupdate == expected) {
            return true;
        }

        delay(20);
    }

    return false;
}

static bool bat_begin_cfg_update(void)
{
    return bat_write_control(bq27220_cfg::ctrl_enter_cfg_update);
}

static bool bat_end_cfg_update(bool reinit)
{
    return bat_write_control(reinit ? bq27220_cfg::ctrl_exit_cfg_update_reinit : bq27220_cfg::ctrl_exit_cfg_update);
}

static bool bat_write_dm_u16_be(uint16_t address, uint16_t value)
{
    uint8_t packet[5] = {
        0x3E,
        (uint8_t)(address & 0xFF),
        (uint8_t)((address >> 8) & 0xFF),
        (uint8_t)((value >> 8) & 0xFF),
        (uint8_t)(value & 0xFF),
    };
    uint8_t checksum = 0;
    uint8_t i = 0;

    for (i = 1; i < sizeof(packet); i++) {
        checksum = (uint8_t)(checksum + packet[i]);
    }
    checksum = (uint8_t)(0xFF - checksum);

    Wire.beginTransmission(BQ27220_I2C_ADDRESS);
    Wire.write(packet, sizeof(packet));
    if (Wire.endTransmission() != 0) {
        return false;
    }
    delay(10);

    Wire.beginTransmission(BQ27220_I2C_ADDRESS);
    Wire.write((uint8_t)0x60);
    Wire.write(checksum);
    Wire.write((uint8_t)6);
    if (Wire.endTransmission() != 0) {
        return false;
    }
    delay(10);

    return true;
}

static bq27220_profile_t bat_make_profile(uint16_t mah)
{
    bq27220_profile_t profile = {
        .full_charge_cap = mah,
        .design_cap = mah,
        .reserve_cap = 0,
        .near_full = 200,
        .self_discharge_rate = 20,
        .edv0 = 3490,
        .edv1 = 3511,
        .edv2 = 3535,
        .emf = 3670,
        .c0 = 115,
        .r0 = 968,
        .t0 = 4547,
        .r1 = 4764,
        .tc = 11,
        .c1 = 0,
        .dod0 = 4147,
        .dod10 = 4002,
        .dod20 = 3969,
        .dod30 = 3938,
        .dod40 = 3880,
        .dod50 = 3824,
        .dod60 = 3794,
        .dod70 = 3753,
        .dod80 = 3677,
        .dod90 = 3574,
        .dod100 = 3490,
    };

    if (mah > 0) {
        profile.near_full = (uint16_t)((200UL * mah) / 650UL);
    }

    return profile;
}

static bool bat_apply_capacity_profile(uint16_t mah)
{
    bq27220_profile_t profile = {};
    int design_capacity = 0;
    int full_charge_capacity = 0;

    if (mah == 0) {
        return false;
    }

    profile = bat_make_profile(mah);

    design_capacity = bq27220.readDesignCapacitymAh();
    full_charge_capacity = bq27220.readFullChargeCapacitymAh();
    if ((design_capacity == (int)mah) && (full_charge_capacity == (int)mah)) {
        return true;
    }

    if (!bat_unseal()) {
        return false;
    }
    delay(10);

    bat_write_control(BQ27220_CTRL_FULL_ACCESS);
    delay(10);

    if (!bat_begin_cfg_update()) {
        return false;
    }

    if (!bat_wait_cfgupdate(true)) {
        bat_end_cfg_update(false);
        return false;
    }

    if (!bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::gauging_configuration, bq27220_cfg::gauging_configuration_default) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::full_charge_capacity, profile.full_charge_cap) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::design_capacity, profile.design_cap) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::near_full, profile.near_full) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::self_discharge_rate, profile.self_discharge_rate) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::reserve_capacity, profile.reserve_cap) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::emf, profile.emf) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::c0, profile.c0) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::r0, profile.r0) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::t0, profile.t0) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::r1, profile.r1) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::tc, (uint16_t)(((uint16_t)profile.tc << 8) | profile.c1)) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod0, profile.dod0) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod10, profile.dod10) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod20, profile.dod20) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod30, profile.dod30) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod40, profile.dod40) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod50, profile.dod50) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod60, profile.dod60) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod70, profile.dod70) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod80, profile.dod80) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod90, profile.dod90) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::dod100, profile.dod100) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::edv0, profile.edv0) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::edv1, profile.edv1) ||
        !bat_write_dm_u16_be(bq27220_cfg::dm_addr_t::edv2, profile.edv2)) {
        bat_end_cfg_update(false);
        return false;
    }

    if (!bat_end_cfg_update(true)) {
        return false;
    }

    if (!bat_wait_cfgupdate(false)) {
        return false;
    }

    delay(100);

    design_capacity = bq27220.readDesignCapacitymAh();
    bat_write_control(BQ27220_CTRL_SEALED);
    return design_capacity == (int)mah;
}

static bool bat_create(uint16_t mah)
{
    bq27220_capacity_mah = mah;
    bq27220_initialized = bq27220.begin(Wire, BQ27220_I2C_ADDRESS, BSP_I2C_SDA, BSP_I2C_SCL, BSP_I2C_CLOCK_HZ);
    if (!bq27220_initialized) {
        return false;
    }

    bat_apply_capacity_profile(mah);
    return true;
}

static bool bat_recover(void)
{
    if (bq27220_capacity_mah == 0) {
        return false;
    }

    bq27220.reset();
    delay(100);
    return bat_create(bq27220_capacity_mah);
}

static bool bat_sample_is_valid(const bsp_bq27220_measurement_t *measurement)
{
    if (measurement == NULL) {
        return false;
    }

    return (measurement->voltage >= 2500) &&
        (measurement->voltage <= 5000) &&
        (measurement->state_of_charge <= 100) &&
        (measurement->temperature >= 2000) &&
        (measurement->temperature <= 4000);
}

static bool bat_sample_is_transient(const bsp_bq27220_measurement_t *measurement)
{
    if (measurement == NULL) {
        return false;
    }

    return (measurement->current == 0) &&
        (measurement->state_of_charge == 0) &&
        (measurement->remaining_capacity == 0) &&
        (measurement->full_charge_capacity > 0) &&
        (measurement->voltage >= 3500) &&
        (measurement->voltage <= 3900);
}

static bool bat_get_measurement(bsp_bq27220_measurement_t *measurement)
{
    float temp_c = NAN;

    if (measurement == NULL) {
        return false;
    }

    temp_c = bq27220.readTemperatureCelsius();
    if (isnan(temp_c)) {
        return false;
    }

    measurement->voltage = (uint16_t)bq27220.readVoltageMillivolts();
    measurement->current = (int16_t)bq27220.readCurrentMilliamps();
    measurement->remaining_capacity = (uint16_t)bq27220.readRemainingCapacitymAh();
    measurement->full_charge_capacity = (uint16_t)bq27220.readFullChargeCapacitymAh();
    measurement->temperature = (uint16_t)((temp_c + 273.15f) * 10.0f);
    measurement->cycle_count = (uint16_t)bq27220.readCycleCount();
    measurement->state_of_charge = (uint16_t)bq27220.readStateOfChargePercent();
    measurement->average_power = 0;
    measurement->maxload_current = 0;
    measurement->time_to_empty = (uint16_t)bq27220.readTimeToEmptyMinutes();
    measurement->time_to_full = (uint16_t)bq27220.readTimeToFullMinutes();
    measurement->state_of_health = (uint16_t)bq27220.readStateOfHealthPercent();

    if ((int)measurement->voltage < 0 ||
        (int)measurement->remaining_capacity < 0 ||
        (int)measurement->full_charge_capacity < 0 ||
        (int)measurement->cycle_count < 0 ||
        (int)measurement->state_of_charge < 0 ||
        (int)measurement->state_of_health < 0) {
        return false;
    }

    return true;
}

bool bsp_i2c_init(void)
{
    return board_i2c_init();
}

bool bsp_display_init_with_config(const bsp_display_cfg_t *cfg)
{
    if (cfg == NULL) {
        return false;
    }

    if (!lcd_init(cfg)) {
        return false;
    }

    return board_backlight_init();
}

bool bsp_display_init(void)
{
    return bsp_display_init_with_config(&default_display_cfg);
}

bool bsp_display_fill(uint16_t color)
{
    return lcd_fill(color);
}

bool bsp_display_draw_bitmap(int x_start, int y_start, int x_end, int y_end, const uint16_t *data)
{
    return lcd_draw_bitmap(x_start, y_start, x_end, y_end, data);
}

bool bsp_display_brightness_init(void)
{
    return board_backlight_init();
}

bool bsp_display_brightness_set(uint8_t brightness_percent)
{
    return board_backlight_set(brightness_percent);
}

int bsp_display_brightness_get(void)
{
    return board_backlight_get();
}

bool bsp_display_backlight_on(void)
{
    return bsp_display_brightness_set(100);
}

bool bsp_display_backlight_off(void)
{
    return bsp_display_brightness_set(0);
}

bool bsp_touch_init(void)
{
    return false;
}

bool bsp_touch_get_coordinates(bsp_touch_data_t *data)
{
    if (data == NULL) {
        return false;
    }

    data->pressed = false;
    data->x = 0;
    data->y = 0;
    return false;
}

bool bsp_bat_init(uint16_t mah)
{
    if (!board_i2c_init()) {
        return false;
    }

    return bat_create(mah);
}

bool bsp_get_bat_info(bsp_bat_info_t *bat_info)
{
    bsp_bq27220_measurement_t measurement = {};
    uint8_t retry = 0;

    if (bat_info == NULL) {
        return false;
    }

    if (!bq27220_initialized) {
        if (!bat_recover()) {
            return false;
        }
    }

    while (retry < 3) {
        if (bat_get_measurement(&measurement) && bat_sample_is_valid(&measurement)) {
            if (bat_sample_is_transient(&measurement)) {
                retry++;
                if (retry >= 3) {
                    return false;
                }
                if (!bat_recover()) {
                    return false;
                }
                delay(50);
                continue;
            }

            bat_info->mv = measurement.voltage;
            bat_info->ma = measurement.current;
            bat_info->mah_rem = measurement.remaining_capacity;
            bat_info->mah_fcc = measurement.full_charge_capacity;
            bat_info->tc = (int16_t)(measurement.temperature / 10) - 273;
            bat_info->cycles = measurement.cycle_count;
            bat_info->soc = measurement.state_of_charge;
            bat_info->mw = measurement.average_power;
            bat_info->max_load = measurement.maxload_current;
            bat_info->tte = measurement.time_to_empty;
            bat_info->ttf = measurement.time_to_full;
            bat_info->soh = measurement.state_of_health;
            return true;
        }

        retry++;
        if (retry >= 3) {
            break;
        }

        if ((retry == 1) && !bat_recover()) {
            return false;
        }

        delay(50);
    }

    return false;
}

bool bsp_bat_is_connected(void)
{
    bsp_bat_info_t bat_info = {};

    if (!bsp_get_bat_info(&bat_info)) {
        return false;
    }

    return bat_info.ma != 0;
}
